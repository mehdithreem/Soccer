create function recursive_league_timeset(teams character varying[], time_level integer, league_id integer, OUT time_levelo integer) returns integer
LANGUAGE plpgsql
AS $$
declare
	arr_size int;
	t1 varchar(20)[];
	t2 varchar(20)[];
	a1 int;
	a2 int;	
	host varchar(20);
	guest varchar(20);
	i int;
	j int;
begin
	SELECT array_length(teams,1) into arr_size;
	-- raise notice 'arr_size : %',arr_size;	
	IF arr_size = 2 then
		-- raise notice 'HERE : %, %',teams[1], teams[2];			
		INSERT INTO game (host_team, guest_team, start_time, league, ticket_price)
					VALUES (teams[1], teams[2], time_level, league_id, 100 );
		INSERT INTO game (host_team, guest_team, start_time, league, ticket_price)
					VALUES (teams[2], teams[1], 0-(time_level+1), league_id, 100 );
		time_levelo = time_level;
	ELSE
		-- raise notice 'arr_size : %',arr_size;
		
		SELECT recursive_league_timeset(teams[0:(arr_size/2)], time_level, league_id) into a1;
		SELECT recursive_league_timeset(teams[(arr_size/2)+1:arr_size], time_level, league_id) into a2;
		
		time_levelo = a1+1;
		FOR i IN 0..(arr_size/2-1) LOOP
			FOR j IN 1..arr_size/2 LOOP
				INSERT INTO game (host_team, guest_team, start_time, league, ticket_price)
					VALUES ( teams[(i+j)%(arr_size/2)+1], teams[ (arr_size/2)+j], time_levelo, league_id, 100 );
				INSERT INTO game (host_team, guest_team, start_time, league, ticket_price)
					VALUES ( teams[ (arr_size/2)+j],  teams[(i+j)%(arr_size/2)+1], 0-(time_levelo+1), league_id, 100 );
			END LOOP;
			time_levelo = time_levelo +1;			
		END LOOP;
	END IF;
end;
$$;
