create function calculate_game_income(game_id integer, target_team character varying) returns integer
LANGUAGE plpgsql
AS $$
declare
	income int;
	target_game record;
	target_team_stadium record;
	stadium_capacity int;
begin
	income = 0;
	select * into target_game from game g where g.id = game_id;
	select * into target_team_stadium from team_stadium ts where ts.team_name = target_game.host_team;
	select capacity into stadium_capacity from stadium_data sd where sd.name = target_team_stadium.stadium_name;
	if (target_game.host_team = target_team) then
		income = calculate_team_satisfaction(target_team) * target_game.ticket_price * 0.9 * stadium_capacity * target_team_stadium.seat_quality;
	elsif (target_game.guest_team = target_team) then
		income = calculate_team_satisfaction(target_team) * target_game.ticket_price * 0.1 * stadium_capacity * target_team_stadium.seat_quality;
	end if;

	return income;
end;
$$;
