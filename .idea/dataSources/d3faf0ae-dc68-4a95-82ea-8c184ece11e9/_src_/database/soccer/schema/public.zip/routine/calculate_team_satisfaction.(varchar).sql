create function calculate_team_satisfaction(in_team character varying) returns real
LANGUAGE plpgsql
AS $$
declare
	g record;
	satisfaction real;
	toilet_q real;
begin
	satisfaction = 0;

	for g in 
		select is_host_win, host_team, guest_team
			from game
			where host_team = in_team or guest_team = in_team
		order by start_time desc limit 10
	loop
		if (in_team = g.host_team and g.is_host_win = 1)
			or (in_team = g.guest_team and g.is_host_win = -1) then
			satisfaction = satisfaction + 10;
		elsif (g.is_host_win = 0) then
			satisfaction = satisfaction + 5;
		elsif (g.is_host_win is not null) then
			satisfaction = satisfaction + 1;
		end if;
	end loop;

	select toilet_quality into toilet_q
		from team_stadium ts
		where ts.team_name = in_team;

	if (toilet_q < 0) then
		satisfaction = satisfaction - 20;
	end if;

	if (satisfaction < 0) then
		satisfaction = 0;
	end if;

	return satisfaction /100;
end;
$$;
