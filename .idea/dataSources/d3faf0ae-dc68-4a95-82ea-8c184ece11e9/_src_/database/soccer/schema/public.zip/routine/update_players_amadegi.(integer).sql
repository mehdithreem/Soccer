create function update_players_amadegi(game_id integer) returns void
LANGUAGE plpgsql
AS $$
declare
	cur_players CURSOR(_host varchar(20), _guest varchar(20)) FOR
		select player, role
		from plays_in pi
		where (pi.team = _host) or (pi.team = _guest);
	target_player record;
	target_team record;
begin
	select g.host_team, g.guest_team into target_team
		from game g
		where g.id = game_id;

	open cur_players(target_team.host_team, target_team.guest_team);
	loop
		fetch cur_players into target_player;
		exit when not found;

		if target_player.role = 'bench' then
			update player pt
				set amadegi = amadegi + amadegi * 0.05
				where pt.name = target_player.player;
		else
			update player pt
				set amadegi = amadegi - amadegi * 0.05
				where pt.name = target_player.player;
		end if;
	end loop;
	close cur_players;
end;
$$;
