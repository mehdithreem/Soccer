create function update_stadium_quality(game_id integer) returns void
LANGUAGE plpgsql
AS $$
declare
	target_game record;
	seat_coeff int;
begin
	select * into target_game from game g where g.id = game_id;
	seat_coeff = 1;

	if (target_game.is_host_win = -1) then
		seat_coeff = 0.8;
	end if;

	update team_stadium
		set seat_quality = seat_quality * seat_coeff,
			toilet_quality = toilet_quality - 0.15,
			grass_quality = grass_quality * 0.85
		where team_name = target_game.host_team;
end;
$$;
