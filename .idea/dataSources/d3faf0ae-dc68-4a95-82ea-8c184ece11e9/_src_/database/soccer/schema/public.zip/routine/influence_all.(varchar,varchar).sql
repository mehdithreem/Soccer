create function influence_all(in_team character varying, in_coach character varying) returns void
LANGUAGE plpgsql
AS $$
declare
	pi record;
begin
	for pi in
		select player from plays_in
		where plays_in.team = in_team
	loop
		PERFORM influence_player(in_coach, pi.player);
	end loop;
end;
$$;
