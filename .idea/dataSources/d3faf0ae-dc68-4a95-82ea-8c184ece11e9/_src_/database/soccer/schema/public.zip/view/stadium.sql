CREATE VIEW stadium AS SELECT st.name,
    st.capacity,
    (st.capacity * 10000) AS price
   FROM stadium_data st;
