create function league_timeset(league_id integer) returns void
LANGUAGE plpgsql
AS $$
declare
	teams varchar(20)[];
	res int;
begin
	select array_agg(team::varchar(20)) into teams from league_team where league = league_id;
	select recursive_league_timeset(teams, 0, league_id) into res;
	-- raise notice 'res : %',res;

end;
$$;
