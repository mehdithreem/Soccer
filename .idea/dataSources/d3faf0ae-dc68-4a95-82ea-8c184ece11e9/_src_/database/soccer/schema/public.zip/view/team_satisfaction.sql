CREATE VIEW team_satisfaction AS SELECT team.name,
    calculate_team_satisfaction(team.name) AS satisfaction
   FROM team;
