create function influence_player(in_coach character varying, in_player character varying) returns void
LANGUAGE plpgsql
AS $$
declare
	target_player record;
	target_coach record;

	ghodrat_badani_coeff int;
	ghodrat_pass_coeff int;
	toop_giri_coeff int;
	ghodrat_golzani_coeff int;
	ghodrat_shoot_coeff int;
	sorat_coeff int;
	darvazebani_coeff int;
begin
	select * into target_coach from coach where coach.name = in_coach;

	ghodrat_badani_coeff = 0;
	ghodrat_pass_coeff = 0;
	toop_giri_coeff = 0;
	ghodrat_golzani_coeff = 0;
	ghodrat_shoot_coeff = 0;
	sorat_coeff = 0;
	darvazebani_coeff = 0;

	case target_coach.duty
	when 'goalkeeping' then
		darvazebani_coeff = 1;
		ghodrat_badani_coeff = 1;
		toop_giri_coeff = 1;
	when 'tactical' then
		toop_giri_coeff = 1;
		ghodrat_pass_coeff = 1;
		ghodrat_golzani_coeff = 1;
	when 'fitness' then
		ghodrat_badani_coeff = 1;
		ghodrat_shoot_coeff = 1;
	end case;

	update player p
		set
			ghodrat_badani = ghodrat_badani + target_coach.exprience * ghodrat_badani_coeff,
			ghodrat_pass = ghodrat_pass + target_coach.exprience * ghodrat_pass_coeff,
			toop_giri = toop_giri + target_coach.exprience * toop_giri_coeff,
			ghodrat_golzani = ghodrat_golzani + target_coach.exprience * ghodrat_golzani_coeff,
			ghodrat_shoot = ghodrat_shoot + target_coach.exprience * ghodrat_shoot_coeff,
			sorat = sorat + target_coach.exprience * sorat_coeff,
			darvazebani = darvazebani + target_coach.exprience * darvazebani_coeff
		where
			p.name = in_player;
end;
$$;
