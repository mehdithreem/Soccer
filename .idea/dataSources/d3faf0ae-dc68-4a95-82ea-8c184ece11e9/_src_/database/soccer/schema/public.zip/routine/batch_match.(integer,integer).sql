create function batch_match(league_id integer, match_series integer) returns void
LANGUAGE plpgsql
AS $$
declare
	g record;
begin
	for g in 
		select game.id, game.host_team, game.guest_team
			from game
			where game.league = league_id and game.start_time = match_series
	loop
		PERFORM match(g.id);
		PERFORM update_players_amadegi(g.id);
		PERFORM update_stadium_quality(g.id);

		update team
			set money = money + calculate_game_income(g.id, g.host_team)
			where team.name = g.host_team;

		update team
			set money = money + calculate_game_income(g.id, g.guest_team)
			where team.name = g.guest_team;
	end loop;
end;
$$;
