create function buy_player(in_player character varying, in_year integer, in_team character varying) returns void
LANGUAGE plpgsql
AS $$
declare
	dealer_leverage real;
	player_price int;
begin
	dealer_leverage = 1;
	select leverage into dealer_leverage from dealer d
		where exists(
			select * from contract where 
				person = d.name and
				team = in_team and
				year = in_year
		);
	
	select price into player_price from person where person.name = in_player;
	insert into contract values
		(in_team, in_player, in_year);
	update team
		set money = money - (player_price * dealer_leverage)
		where name = in_team;

end;
$$;
