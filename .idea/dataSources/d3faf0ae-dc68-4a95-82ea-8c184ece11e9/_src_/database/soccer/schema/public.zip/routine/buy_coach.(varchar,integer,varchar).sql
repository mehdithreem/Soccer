create function buy_coach(in_coach character varying, in_year integer, in_team character varying) returns void
LANGUAGE plpgsql
AS $$
declare
	coach_price int;
begin
	select price into coach_price from person where person.name = in_coach;
	insert into contract values
		(in_team, in_coach, in_year);
	update team
		set money = money - coach_price
		where name = in_team;
end;
$$;
