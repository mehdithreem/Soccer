create function buy_dealer(in_dealer character varying, in_year integer, in_team character varying) returns integer
LANGUAGE plpgsql
AS $$
declare
	current_contract record;
	error int;
	dealer_price int;
begin
	error = 0;
	for current_contract in
		select * from contract c
			where c.year = in_year and c.team = in_team
	loop
		if (exists(select * from dealer d where d.name = current_contract.person)) then
			error = 1;
			exit;
		end if;
	end loop;

	if (error = 0) then
		select price into dealer_price from person where person.name = in_dealer;
		insert into contract values
			(in_team, in_dealer, in_year);
		update team
			set money = money - dealer_price
			where name = in_team;
	end if;

	return error;
end;
$$;
