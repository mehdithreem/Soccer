create function match(game_id integer) returns void
LANGUAGE plpgsql
AS $$
declare
	target_game record;
	host_score int;
	guest_score int;
	o_is_host_win int;
begin
	select * into target_game from game where game.id = game_id;

	host_score = 0;
	guest_score = 0;

	select
		COALESCE(sum(amadegi),0) +
		COALESCE(sum(ghodrat_badani),0) +
		COALESCE(sum(ghodrat_pass),0) +
		COALESCE(sum(toop_giri),0) +
		COALESCE(sum(ghodrat_golzani),0) +
		COALESCE(sum(ghodrat_shoot),0) +
		COALESCE(sum(sorat),0) +
		COALESCE(sum(darvazebani),0)
		into host_score
		from player p
		where exists(
			select role from plays_in pi
			where (pi.player = p.name) and
				(pi.team = target_game.host_team) and
				(role != 'bench')
		);

	select
		COALESCE(sum(amadegi),0) +
		COALESCE(sum(ghodrat_badani),0) +
		COALESCE(sum(ghodrat_pass),0) +
		COALESCE(sum(toop_giri),0) +
		COALESCE(sum(ghodrat_golzani),0) +
		COALESCE(sum(ghodrat_shoot),0) +
		COALESCE(sum(sorat),0) +
		COALESCE(sum(darvazebani),0)
		into guest_score
		from player p
		where exists(
			select role from plays_in pi
			where (pi.player = p.name) and
				(pi.team = target_game.guest_team) and
				(role != 'bench')
		);

	if (host_score > guest_score) then
		o_is_host_win = 1;
	elsif (host_score < guest_score) then
		o_is_host_win = -1;
	else
		o_is_host_win = 0;
	end if;

	update game
		set is_host_win = o_is_host_win
		where game.id = target_game.id;
end;
$$;
